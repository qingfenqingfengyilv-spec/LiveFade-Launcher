# LiveFade Launcher

A minimal Android Home/Launcher prototype. It displays launcher activities over the
currently selected system wallpaper, fades the icon grid after 3.5 seconds of idle,
and consumes the first touch while hidden so that the wake tap cannot launch an app.

## Requirements
- Android Studio with JDK 17
- Android SDK Platform 35
- Gradle plugin 8.7.3 (Android Studio can download it)

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK.
5. In system Settings, allow changing the system Home screen if that toggle exists.
6. Set **LiveFade Launcher** as the default Home app.

## Important OriginOS test
The app uses Android's `FLAG_SHOW_WALLPAPER` and a translucent Home window. This is the
standard Android mechanism for drawing the system wallpaper behind an app window, but
some OEM desktop/window-manager implementations may differ. Verify your existing live
wallpaper remains animated after selecting this launcher. If OriginOS renders a black
or static background, this prototype is not compatible with that build and should not
be used as the default launcher until the window/wallpaper behavior is corrected.

## Current prototype scope
- Lists activities that declare `ACTION_MAIN` + `CATEGORY_LAUNCHER`.
- Four-column app grid.
- 3.5-second idle hide and fade animation.
- First DOWN while hidden wakes the icons and consumes that gesture.
- No widgets, folders, app drawer search, icon rearrangement, or settings screen yet.

## Restore the stock launcher
Settings > Apps > Default apps > Home app (wording varies) > select the system launcher.
