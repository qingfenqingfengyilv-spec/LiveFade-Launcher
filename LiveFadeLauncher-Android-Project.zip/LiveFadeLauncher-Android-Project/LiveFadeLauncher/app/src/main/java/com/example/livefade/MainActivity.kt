package com.example.livefade

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        private const val IDLE_HIDE_MS = 3_500L
        private const val GRID_COLUMNS = 4
        private const val ICON_SIZE_DP = 54
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var iconLayer: GridLayout
    private var iconsVisible = true
    private var consumingWakeGesture = false

    private val hideTask = Runnable { hideIcons() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask Android to composite the currently selected system wallpaper behind
        // this translucent Home window. The wallpaper itself remains owned by
        // WallpaperManager / the system wallpaper service.
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        iconLayer = GridLayout(this).apply {
            columnCount = GRID_COLUMNS
            useDefaultMargins = true
            setPadding(dp(12), dp(28), dp(12), dp(24))
            alpha = 1f
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }

        val scrollContainer = android.widget.ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.TRANSPARENT)
            addView(
                iconLayer,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        root.addView(
            scrollContainer,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        setContentView(root)
        populateApps()
        scheduleHide()
    }

    override fun onResume() {
        super.onResume()
        if (::iconLayer.isInitialized && iconsVisible) scheduleHide()
    }

    override fun onPause() {
        handler.removeCallbacks(hideTask)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    /**
     * Hidden-state first DOWN restores the icons and consumes the complete
     * gesture. It never reaches a child icon, so the wake tap cannot launch
     * an app accidentally.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Once a hidden-state DOWN wakes the grid, consume every remaining
        // event in that same gesture even though iconsVisible is now true.
        if (consumingWakeGesture) {
            if (ev.actionMasked == MotionEvent.ACTION_UP ||
                ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                consumingWakeGesture = false
                scheduleHide()
            }
            return true
        }

        if (!iconsVisible && ev.actionMasked == MotionEvent.ACTION_DOWN) {
            consumingWakeGesture = true
            showIcons()
            return true
        }

        return super.dispatchTouchEvent(ev)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (iconsVisible) scheduleHide()
    }

    private fun populateApps() {
        iconLayer.removeAllViews()

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities: List<ResolveInfo> = packageManager.queryIntentActivities(launcherIntent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        for (resolveInfo in activities) {
            val appIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = android.content.ComponentName(
                    resolveInfo.activityInfo.packageName,
                    resolveInfo.activityInfo.name
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(9), dp(5), dp(9))
                isClickable = true
                isFocusable = true
                contentDescription = resolveInfo.loadLabel(packageManager)
            }

            val icon = ImageView(this).apply {
                setImageDrawable(resolveInfo.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(
                icon,
                LinearLayout.LayoutParams(dp(ICON_SIZE_DP), dp(ICON_SIZE_DP))
            )

            val label = TextView(this).apply {
                text = resolveInfo.loadLabel(packageManager)
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                maxLines = 2
                setShadowLayer(4f, 0f, 1f, Color.BLACK)
                setPadding(0, dp(5), 0, 0)
            }
            item.addView(
                label,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )

            item.setOnClickListener {
                try {
                    startActivity(appIntent)
                } catch (_: Exception) {
                    // An app may have been uninstalled or disabled since listing.
                    populateApps()
                }
            }

            val cell = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            iconLayer.addView(item, cell)
        }
    }

    private fun hideIcons() {
        if (!iconsVisible || isFinishing) return
        iconsVisible = false
        iconLayer.animate().cancel()
        iconLayer.animate()
            .alpha(0f)
            .setDuration(420L)
            .withEndAction {
                if (!iconsVisible) iconLayer.visibility = View.INVISIBLE
            }
            .start()
    }

    private fun showIcons() {
        handler.removeCallbacks(hideTask)
        iconsVisible = true
        iconLayer.animate().cancel()
        iconLayer.visibility = View.VISIBLE
        iconLayer.alpha = 0f
        iconLayer.animate()
            .alpha(1f)
            .setDuration(260L)
            .start()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideTask)
        if (iconsVisible) handler.postDelayed(hideTask, IDLE_HIDE_MS)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()
}
