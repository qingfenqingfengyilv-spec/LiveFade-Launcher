extends Node2D

# Forest Firefly: landscape prototype with procedural art and animated character.
const PLAYER_SPEED := 255.0
const PLAYER_RADIUS := 23.0
const JOYSTICK_RADIUS := 76.0
const ATTACK_RADIUS := 58.0
const SKILL_RADIUS := 38.0
const FIRE_INTERVAL := 5.0 / 3.0 # Three shots every five seconds while the attack control is held.
const PROJECTILE_SPEED := 520.0
const AIM_RANGE_BY_STAR := [0.0, 250.0, 340.0, 450.0, 590.0, 100000.0]
const STAR_FIRE_BUFF := {3: {"kills": 10, "bonus": 0.12, "duration": 5.0}, 4: {"kills": 10, "bonus": 0.22, "duration": 8.0}, 5: {"kills": 5, "bonus": 0.55, "duration": 12.0}}

var player_pos := Vector2.ZERO
var move_input := Vector2.ZERO
var joystick_touch := -1
var attack_touch := -1
var dash_touch := -1
var skill_touches: Array[int] = []
var game_paused := false
var upgrade_pending := false
var sfx_players: Dictionary = {}
var health := 100.0
var max_health := 100.0
var talent_levels := {"生命": 1, "攻击": 1, "防御": 1, "移速": 1}
# Player progression (EXP level) is separate from the 100 timed stages.
var player_level := 0
var exp_points := 0
var exp_to_next := 5
var run_level := 1
var level_time := 0.0
const LEVEL_DURATION := 480.0 # 8 minutes of survival per stage
const MAX_ACTIVE_ENEMIES := 52
var enemy_target_count := 8
var enemies_spawned := 0
var enemies_defeated := 0
var enemy_spawn_timer := 0.0
var enemies: Array[Dictionary] = []
var game_over := false
var game_complete := false
var equipment_slots := 4
var weapon_star := 1
var kill_streak_for_fire := 0
var fire_buff_timer := 0.0
var potion_counts := {"大": 0, "中": 0, "小": 0}
var potion_drop_total := 0
var potion_drops: Array[Dictionary] = []
var golden_drops: Array[Dictionary] = []
var weapon_drops: Array[Dictionary] = []
var golden_shots := 0
var boss_spawned_this_stage := false
var skill_points := 0
var total_skill_points_earned := 0
var exit_confirm := false
var grass_colors := [Color("#1a3322"), Color("#29482a"), Color("#355b31"), Color("#496d37"), Color("#668345"), Color("#82914c")]
var joystick_origin := Vector2.ZERO
var joystick_knob := Vector2.ZERO
var dash_flash := 0.0
var attack_flash := 0.0
var skill_flash := 0.0
var time_passed := 0.0
var attack_cooldown := 0.0
var dash_cooldown := 0.0
var player_hit_cooldown := 0.0
var attack_angle := 0.0
var walk_phase := 0.0
var facing := Vector2.RIGHT
var projectiles: Array[Dictionary] = []
var next_enemy_id := 1
var flowers: Array[Dictionary] = []
var grass_blades: Array[Dictionary] = []
var trees: Array[Dictionary] = []
var rocks: Array[Dictionary] = []
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    _build_forest()
    _setup_sfx()
    _start_stage(1)
    var s := get_viewport_rect().size
    player_pos = s * Vector2(0.5, 0.51)
    _reset_joystick()
    get_viewport().size_changed.connect(_on_viewport_changed)
    Engine.max_fps = 60
    queue_redraw()

func _setup_sfx() -> void:
    for key in ["attack", "hit", "level", "select"]:
        var player := AudioStreamPlayer.new()
        player.name = "SFX_" + key
        player.stream = load("res://audio/" + key + ".wav")
        player.volume_db = -8.0 if key == "attack" else -4.0
        add_child(player)
        sfx_players[key] = player

func _play_sfx(key: String) -> void:
    if sfx_players.has(key):
        var player: AudioStreamPlayer = sfx_players[key]
        player.stop()
        player.play()

func _reset_joystick() -> void:
    var s := get_viewport_rect().size
    joystick_origin = Vector2(s.x * 0.13, s.y * 0.79)
    joystick_knob = joystick_origin

func _on_viewport_changed() -> void:
    var s := get_viewport_rect().size
    player_pos.x = clampf(player_pos.x, 40.0, s.x - 40.0)
    player_pos.y = clampf(player_pos.y, 45.0, s.y - 45.0)
    _reset_joystick()
    _build_forest()
    queue_redraw()

func _build_forest() -> void:
    var s := get_viewport_rect().size
    flowers.clear()
    grass_blades.clear()
    trees.clear()
    rocks.clear()
    for i in range(105):
        flowers.append({
            "p": Vector2(rng.randf_range(25.0, s.x - 25.0), rng.randf_range(30.0, s.y - 30.0)),
            "kind": rng.randi_range(0, 4),
            "scale": rng.randf_range(0.55, 1.2),
            "phase": rng.randf_range(0.0, TAU)
        })
    # Dense, irregular grass clumps. The blades are individual shapes, not a few lines on a flat floor.
    for clump in range(118):
        var center := Vector2(rng.randf_range(18.0, s.x - 18.0), rng.randf_range(25.0, s.y - 25.0))
        var count := rng.randi_range(3, 5)
        for j in range(count):
            var base: Vector2 = center + Vector2(rng.randf_range(-13.0, 13.0), rng.randf_range(-7.0, 7.0))
            grass_blades.append({
                "p": base,
                "h": rng.randf_range(7.0, 24.0),
                "w": rng.randf_range(1.1, 3.0),
                "lean": rng.randf_range(-9.0, 9.0),
                "tone": rng.randi_range(0, 5),
                "phase": rng.randf_range(0.0, TAU)
            })
    # Keep the central play area clearer; trees frame the meadow edges.
    for i in range(30):
        var side := rng.randi_range(0, 3)
        var p := Vector2.ZERO
        if side == 0:
            p = Vector2(rng.randf_range(25, s.x - 25), rng.randf_range(30, 92))
        elif side == 1:
            p = Vector2(rng.randf_range(25, s.x - 25), rng.randf_range(s.y - 92, s.y - 25))
        elif side == 2:
            p = Vector2(rng.randf_range(25, 90), rng.randf_range(90, s.y - 90))
        else:
            p = Vector2(rng.randf_range(s.x - 90, s.x - 25), rng.randf_range(90, s.y - 90))
        trees.append({"p": p, "r": rng.randf_range(22.0, 43.0), "tone": rng.randf_range(0.0, 1.0)})
    for i in range(34):
        rocks.append({"p": Vector2(rng.randf_range(35, s.x - 35), rng.randf_range(55, s.y - 55)), "r": rng.randf_range(4.0, 11.0)})

func _process(delta: float) -> void:
    time_passed += delta
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    fire_buff_timer = maxf(0.0, fire_buff_timer - delta)
    dash_cooldown = maxf(0.0, dash_cooldown - delta)
    player_hit_cooldown = maxf(0.0, player_hit_cooldown - delta)
    attack_flash = maxf(0.0, attack_flash - delta * 3.4)
    dash_flash = maxf(0.0, dash_flash - delta * 2.2)
    skill_flash = maxf(0.0, skill_flash - delta * 2.0)
    var s := get_viewport_rect().size
    if game_paused or upgrade_pending or game_over or game_complete:
        queue_redraw()
        return
    level_time += delta
    _spawn_stage_enemies(delta)
    if move_input.length() > 0.05:
        var direction := move_input.normalized()
        facing = direction
        var move_speed := PLAYER_SPEED * (1.0 + float(talent_levels["移速"] - 1) * 0.05)
        player_pos += direction * move_speed * delta
        walk_phase += delta * 11.0 * clampf(move_input.length(), 0.0, 1.0)
        player_pos.x = clampf(player_pos.x, 38.0, s.x - 38.0)
        player_pos.y = clampf(player_pos.y, 42.0, s.y - 42.0)
    else:
        walk_phase += delta * 2.0
    _update_enemies(delta)
    # Holding the attack control fires automatically at a deliberately slower pace.
    if attack_touch != -1 and attack_cooldown <= 0.0:
        _do_attack()
    _update_pickups(delta)
    for i in range(projectiles.size() - 1, -1, -1):
        var projectile: Dictionary = projectiles[i]
        var projectile_pos: Vector2 = projectile["p"]
        var velocity: Vector2 = projectile.get("v", facing * PROJECTILE_SPEED)
        # Ordinary bullets fly in a fixed straight line. Only the special golden shot homes.
        if bool(projectile.get("homing", false)):
            var target_id := int(projectile.get("target_id", -1))
            var target_pos := Vector2.ZERO
            var target_found := false
            for enemy in enemies:
                if int(enemy.get("id", -2)) == target_id and float(enemy.get("hp", 0.0)) > 0.0:
                    target_pos = enemy["p"]
                    target_found = true
                    break
            if not target_found:
                target_id = _nearest_enemy_id(projectile_pos)
                projectile["target_id"] = target_id
                for enemy in enemies:
                    if int(enemy.get("id", -2)) == target_id and float(enemy.get("hp", 0.0)) > 0.0:
                        target_pos = enemy["p"]
                        target_found = true
                        break
            if target_found:
                var desired := (target_pos - projectile_pos).normalized()
                var current_dir := velocity.normalized() if velocity.length() > 0.01 else desired
                velocity = current_dir.lerp(desired, clampf(delta * 3.8, 0.0, 1.0)).normalized() * PROJECTILE_SPEED
        projectile["v"] = velocity
        projectile["p"] = projectile_pos + velocity * delta
        projectile["life"] = float(projectile.get("life", 3.0)) - delta
        projectile["travelled"] = float(projectile.get("travelled", 0.0)) + PROJECTILE_SPEED * delta
        projectiles[i] = projectile
        var hit_enemy := -1
        for j in range(enemies.size() - 1, -1, -1):
            if float(enemies[j].get("hp", 0.0)) > 0.0 and projectile["p"].distance_to(enemies[j]["p"]) < float(enemies[j]["r"]) + 8.0:
                hit_enemy = j
                break
        if hit_enemy >= 0:
            var enemy: Dictionary = enemies[hit_enemy]
            var damage := float(projectile.get("damage", 10.0))
            if bool(projectile.get("golden", false)) and not bool(enemy.get("boss", false)):
                damage = float(enemy.get("hp", 1.0)) + 1.0
            enemy["hp"] = float(enemy["hp"]) - damage
            enemy["hit_timer"] = 0.18
            if float(enemy["hp"]) <= 0.0:
                enemy["hp"] = 0.0
                enemy["death_timer"] = 0.14
            enemies[hit_enemy] = enemy
            _play_sfx("hit")
            projectiles.remove_at(i)
        elif float(projectile["life"]) <= 0.0 or float(projectile["travelled"]) >= maxf(s.x, s.y) * 1.2:
            projectiles.remove_at(i)
    if health <= 0.0:
        health = 0.0
        game_over = true
        move_input = Vector2.ZERO
        joystick_touch = -1
    if level_time >= LEVEL_DURATION:
        _complete_stage()
    elif enemies_spawned >= enemy_target_count and enemies.is_empty() and weapon_drops.is_empty():
        _complete_stage()
    queue_redraw()

func _start_stage(level: int) -> void:
    run_level = clampi(level, 1, 100)
    level_time = 0.0
    enemy_target_count = _enemy_target_for_level(run_level)
    enemies_spawned = 0
    enemies_defeated = 0
    enemy_spawn_timer = 0.0
    enemies.clear()
    projectiles.clear()
    potion_drops.clear()
    golden_drops.clear()
    weapon_drops.clear()
    boss_spawned_this_stage = false
    upgrade_pending = false
    var boss_level := _boss_kind_for_level(run_level)
    if boss_level != "":
        _spawn_boss(boss_level)

func _enemy_target_for_level(level: int) -> int:
    # Stage growth rate rises by about 2 enemies per level at each phase.
    if level <= 15:
        return int(round(8.0 + float(level - 1) * (32.0 / 14.0)))
    if level <= 35:
        return int(round(42.0 + float(level - 16) * 4.3))
    if level <= 55:
        return int(round(126.0 + float(level - 36) * 6.3))
    if level <= 85:
        return int(round(248.0 + float(level - 56) * 8.3))
    return mini(700, int(round(491.0 + float(level - 86) * 10.3)))

func _boss_kind_for_level(level: int) -> String:
    if level in [8, 25, 45, 70, 93]:
        return "mini"
    if level in [15, 35, 55, 85, 100]:
        return "major"
    return ""

func _spawn_boss(kind: String) -> void:
    var s := get_viewport_rect().size
    var boss_hp := (220.0 + float(run_level) * 14.0) if kind == "major" else (110.0 + float(run_level) * 8.0)
    var boss_radius := 31.0 if kind == "major" else 24.0
    var p := Vector2(s.x * 0.5, 80.0)
    enemies.append({"id": next_enemy_id, "p": p, "r": boss_radius, "speed": 24.0 + float(run_level) * 0.08, "hp": boss_hp, "max_hp": boss_hp, "hit_timer": 0.0, "phase": rng.randf_range(0.0, TAU), "boss": true, "boss_kind": kind})
    next_enemy_id += 1
    boss_spawned_this_stage = true

func _spawn_stage_enemies(delta: float) -> void:
    if enemies_spawned >= enemy_target_count:
        return
    # Keep early-stage enemies from appearing painfully slowly; later stages naturally become denser.
    var interval := minf(LEVEL_DURATION / float(maxi(enemy_target_count, 1)), 1.0)
    enemy_spawn_timer += delta
    if enemy_spawn_timer >= interval and enemies.size() < MAX_ACTIVE_ENEMIES:
        enemy_spawn_timer = 0.0
        _spawn_enemy()

func _spawn_enemy() -> void:
    var s := get_viewport_rect().size
    var side := rng.randi_range(0, 3)
    var p := Vector2.ZERO
    if side == 0:
        p = Vector2(rng.randf_range(12.0, s.x - 12.0), -18.0)
    elif side == 1:
        p = Vector2(rng.randf_range(12.0, s.x - 12.0), s.y + 18.0)
    elif side == 2:
        p = Vector2(-18.0, rng.randf_range(12.0, s.y - 12.0))
    else:
        p = Vector2(s.x + 18.0, rng.randf_range(12.0, s.y - 12.0))
    var size := rng.randf_range(12.0, 17.0) + minf(float(run_level) * 0.025, 2.0)
    var enemy_hp := 10.0 + float(run_level - 1) * 1.6
    enemies.append({"id": next_enemy_id, "p": p, "r": size, "speed": rng.randf_range(28.0, 49.0) + minf(float(run_level) * 0.08, 9.0), "hp": enemy_hp, "max_hp": enemy_hp, "hit_timer": 0.0, "phase": rng.randf_range(0.0, TAU), "boss": false})
    next_enemy_id += 1
    enemies_spawned += 1

func _update_enemies(delta: float) -> void:
    for i in range(enemies.size() - 1, -1, -1):
        var enemy: Dictionary = enemies[i]
        if float(enemy.get("hp", 1.0)) <= 0.0:
            enemy["death_timer"] = float(enemy.get("death_timer", 0.14)) - delta
            if float(enemy["death_timer"]) <= 0.0:
                var dead_enemy: Dictionary = enemy
                enemies.remove_at(i)
                enemies_defeated += 1
                _gain_exp(1)
                _on_enemy_defeated(dead_enemy)
            else:
                enemies[i] = enemy
            continue
        var p: Vector2 = enemy["p"]
        var to_player := player_pos - p
        if to_player.length() > 0.1:
            p += to_player.normalized() * float(enemy["speed"]) * delta
        enemy["p"] = p
        enemy["hit_timer"] = maxf(0.0, float(enemy["hit_timer"]) - delta)
        if p.distance_to(player_pos) < float(enemy["r"]) + PLAYER_RADIUS * 0.55 and player_hit_cooldown <= 0.0:
            var defense := float(talent_levels["防御"]) * 0.05
            health -= 4.0 * (1.0 - clampf(defense, 0.0, 0.75))
            player_hit_cooldown = 0.75
            enemy["hit_timer"] = 0.8
        enemies[i] = enemy

func _on_enemy_defeated(enemy: Dictionary) -> void:
    kill_streak_for_fire += 1
    if STAR_FIRE_BUFF.has(weapon_star):
        var buff: Dictionary = STAR_FIRE_BUFF[weapon_star]
        if kill_streak_for_fire >= int(buff["kills"]):
            kill_streak_for_fire -= int(buff["kills"])
            fire_buff_timer = float(buff["duration"])
    if bool(enemy.get("boss", false)):
        var kind := String(enemy.get("boss_kind", "mini"))
        var max_star := 1
        if run_level == 25:
            max_star = 2
        elif run_level == 35:
            max_star = 3
        elif run_level == 45:
            max_star = 3
        elif run_level == 55:
            max_star = 4
        elif run_level == 70:
            max_star = 4
        elif run_level == 85 or run_level == 100:
            max_star = 5
        elif run_level == 93:
            max_star = 4
        # Mini-bosses have a chance to drop an eligible weapon; major bosses always drop one.
        if kind == "major" or rng.randf() < 0.45:
            var dropped_star := max_star
            if kind == "mini" and max_star > 1:
                dropped_star = rng.randi_range(maxi(1, max_star - 1), max_star)
            elif kind == "major" and max_star > 1 and rng.randf() < 0.12:
                dropped_star = max_star - 1
            weapon_drops.append({"p": enemy.get("p", player_pos), "star": dropped_star, "life": 30.0})
    else:
        _maybe_drop_potion(enemy.get("p", player_pos))
        if rng.randf() < 0.012:
            golden_drops.append({"p": enemy.get("p", player_pos), "life": 18.0})

func _maybe_drop_potion(pos: Vector2) -> void:
    if potion_drop_total >= 4:
        return
    var roll := rng.randf()
    var kind := ""
    if roll < 0.02:
        kind = "大"
    elif roll < 0.09:
        kind = "中"
    elif roll < 0.21:
        kind = "小"
    if kind != "":
        potion_drops.append({"p": pos, "kind": kind, "life": 22.0})
        potion_drop_total += 1

func _update_pickups(delta: float) -> void:
    for i in range(potion_drops.size() - 1, -1, -1):
        var drop: Dictionary = potion_drops[i]
        drop["life"] = float(drop.get("life", 22.0)) - delta
        if player_pos.distance_to(drop["p"]) < PLAYER_RADIUS + 20.0:
            var kind := String(drop["kind"])
            if int(potion_counts.get(kind, 0)) < 3:
                potion_counts[kind] = int(potion_counts.get(kind, 0)) + 1
                potion_drops.remove_at(i)
                continue
        if float(drop["life"]) <= 0.0:
            potion_drops.remove_at(i)
        else:
            potion_drops[i] = drop
    for i in range(golden_drops.size() - 1, -1, -1):
        var gold: Dictionary = golden_drops[i]
        gold["life"] = float(gold.get("life", 18.0)) - delta
        if player_pos.distance_to(gold["p"]) < PLAYER_RADIUS + 19.0:
            golden_shots += 1
            golden_drops.remove_at(i)
        elif float(gold["life"]) <= 0.0:
            golden_drops.remove_at(i)
        else:
            golden_drops[i] = gold
    for i in range(weapon_drops.size() - 1, -1, -1):
        var weapon_drop: Dictionary = weapon_drops[i]
        weapon_drop["life"] = float(weapon_drop.get("life", 30.0)) - delta
        if player_pos.distance_to(weapon_drop["p"]) < PLAYER_RADIUS + 22.0:
            weapon_star = maxi(weapon_star, int(weapon_drop["star"]))
            kill_streak_for_fire = 0
            fire_buff_timer = 0.0
            weapon_drops.remove_at(i)
        elif float(weapon_drop["life"]) <= 0.0:
            weapon_drops.remove_at(i)
        else:
            weapon_drops[i] = weapon_drop

func _use_potion(kind: String) -> void:
    if int(potion_counts.get(kind, 0)) <= 0 or health >= max_health:
        return
    var ratio := 0.7 if kind == "大" else (0.4 if kind == "中" else 0.1)
    health = minf(max_health, health + max_health * ratio)
    potion_counts[kind] = int(potion_counts[kind]) - 1

func _gain_exp(amount: int) -> void:
    exp_points += amount
    while exp_points >= exp_to_next and player_level < 100:
        exp_points -= exp_to_next
        player_level += 1
        _play_sfx("level")
        if player_level == 1:
            exp_to_next = 8
        else:
            exp_to_next = int(ceil(8.0 * pow(1.20, float(player_level - 1))))

func _complete_stage() -> void:
    if upgrade_pending or game_over or game_complete:
        return
    # A stage ends when all planned enemies are defeated OR the 8-minute survival timer expires.
    enemies.clear()
    projectiles.clear()
    move_input = Vector2.ZERO
    joystick_touch = -1
    if run_level >= 100:
        game_complete = true
        return
    upgrade_pending = true
    _play_sfx("level")

func _choose_upgrade(index: int) -> void:
    if not upgrade_pending:
        return
    var keys := ["生命", "攻击", "防御", "移速"]
    if index < 0 or index >= keys.size():
        return
    var key: String = keys[index]
    talent_levels[key] += 1
    if key == "生命":
        max_health += 20.0
        health = minf(max_health, health + 20.0)
    elif key == "攻击":
        # Each attack upgrade adds 3 damage; starting damage is 10.
        pass
    elif key == "防御":
        # 5% per level after the first, capped at 75% in damage calculation.
        pass
    elif key == "移速":
        pass
    _play_sfx("select")
    upgrade_pending = false
    _start_stage(run_level + 1)


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _handle_press(event.index, event.position)
        else:
            _handle_release(event.index)
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            _move_joystick(event.position)
    elif event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT:
            if event.pressed:
                _handle_press(999, event.position)
            else:
                _handle_release(999)
    elif event is InputEventMouseMotion and joystick_touch == 999 and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _move_joystick(event.position)

func _move_joystick(p: Vector2) -> void:
    var drag_delta: Vector2 = p - joystick_origin
    joystick_knob = joystick_origin + drag_delta.limit_length(JOYSTICK_RADIUS)
    move_input = (joystick_knob - joystick_origin) / JOYSTICK_RADIUS

func _control_centers(s: Vector2) -> Dictionary:
    return {
        "joy": Vector2(s.x * 0.13, s.y * 0.79),
        "attack": Vector2(s.x * 0.865, s.y * 0.79),
        "dash": Vector2(s.x * 0.785, s.y * 0.61),
        "pause": Vector2(s.x * 0.055, s.y * 0.075),
        "continue": Vector2(s.x * 0.5, s.y * 0.43),
        "restart": Vector2(s.x * 0.5, s.y * 0.54),
        "exit": Vector2(s.x * 0.5, s.y * 0.65)
    }

func _handle_press(index: int, p: Vector2) -> void:
    var s := get_viewport_rect().size
    var c := _control_centers(s)
    if upgrade_pending:
        var card_width := minf(245.0, s.x * 0.22)
        var gap := 14.0
        var total := card_width * 4.0 + gap * 3.0
        var left := (s.x - total) * 0.5
        for i in range(4):
            var card_rect := Rect2(Vector2(left + float(i) * (card_width + gap), s.y * 0.38), Vector2(card_width, 190.0))
            if card_rect.has_point(p):
                _choose_upgrade(i)
                queue_redraw()
                return
        queue_redraw()
        return
    if game_over or game_complete:
        if Rect2(c["restart"] - Vector2(145, 23), Vector2(290, 46)).has_point(p):
            _restart_run()
        queue_redraw()
        return
    if game_paused:
        if Rect2(c["continue"] - Vector2(145, 23), Vector2(290, 46)).has_point(p):
            game_paused = false
        elif Rect2(c["restart"] - Vector2(145, 23), Vector2(290, 46)).has_point(p):
            _restart_run()
        elif Rect2(c["exit"] - Vector2(145, 23), Vector2(290, 46)).has_point(p):
            get_tree().quit()
        queue_redraw()
        return
    # Four compact right-edge slots: tap to consume stored healing potions.
    var slot_x := s.x * 0.945
    for slot_index in range(3):
        var slot_rect := Rect2(Vector2(slot_x, s.y * 0.47 + float(slot_index) * 39.0), Vector2(31.0, 31.0))
        if slot_rect.has_point(p):
            _use_potion(["大", "中", "小"][slot_index])
            queue_redraw()
            return
    if p.distance_to(c["pause"]) < 42.0:
        game_paused = true
        joystick_touch = -1
        move_input = Vector2.ZERO
        queue_redraw()
    elif p.distance_to(c["joy"]) < JOYSTICK_RADIUS * 1.65 and joystick_touch == -1:
        joystick_touch = index
        joystick_origin = c["joy"]
        _move_joystick(p)
    elif p.distance_to(c["attack"]) < ATTACK_RADIUS * 1.35:
        attack_touch = index
        _do_attack()
    elif p.distance_to(c["dash"]) < SKILL_RADIUS * 1.8:
        dash_touch = index
        _do_dash()
    # Only three gameplay buttons: joystick, attack and dash.

func _handle_release(index: int) -> void:
    if index == joystick_touch:
        joystick_touch = -1
        move_input = Vector2.ZERO
        _reset_joystick()
    if index == attack_touch:
        attack_touch = -1
    if index == dash_touch:
        dash_touch = -1
    skill_touches.erase(index)

func _nearest_enemy_id(from_pos: Vector2) -> int:
    var nearest_id := -1
    var nearest_distance := INF
    for enemy in enemies:
        if float(enemy.get("hp", 0.0)) <= 0.0:
            continue
        var distance: float = from_pos.distance_to(enemy["p"])
        if distance < nearest_distance:
            nearest_distance = distance
            nearest_id = int(enemy.get("id", -1))
    return nearest_id

func _do_attack() -> void:
    if attack_cooldown > 0.0:
        return
    var fire_rate_multiplier := 1.0
    if fire_buff_timer > 0.0 and STAR_FIRE_BUFF.has(weapon_star):
        fire_rate_multiplier += float(STAR_FIRE_BUFF[weapon_star]["bonus"])
    attack_cooldown = FIRE_INTERVAL / fire_rate_multiplier
    attack_flash = 1.0
    _play_sfx("attack")
    var target_id := _nearest_enemy_id_in_range(player_pos, float(AIM_RANGE_BY_STAR[weapon_star]))
    var direction := facing
    if target_id >= 0:
        for enemy in enemies:
            if int(enemy.get("id", -2)) == target_id and float(enemy.get("hp", 0.0)) > 0.0:
                direction = (enemy["p"] - player_pos).normalized()
                break
    if direction.length() < 0.01:
        direction = Vector2.RIGHT
    attack_angle = direction.angle()
    var damage := 10.0 + float(talent_levels["攻击"] - 1) * 3.0
    if golden_shots > 0:
        golden_shots -= 1
        projectiles.append({"p": player_pos + direction * 29.0, "v": direction * PROJECTILE_SPEED, "life": 3.0, "travelled": 0.0, "target_id": target_id, "damage": damage, "homing": true, "golden": true})
    else:
        projectiles.append({"p": player_pos + direction * 29.0, "v": direction * PROJECTILE_SPEED, "life": 3.0, "travelled": 0.0, "target_id": target_id, "damage": damage, "homing": false, "golden": false})

func _nearest_enemy_id_in_range(from_pos: Vector2, max_range: float) -> int:
    var nearest_id := -1
    var nearest_distance := max_range
    for enemy in enemies:
        if float(enemy.get("hp", 0.0)) <= 0.0:
            continue
        var distance: float = from_pos.distance_to(enemy["p"])
        if distance <= nearest_distance:
            nearest_distance = distance
            nearest_id = int(enemy.get("id", -1))
    return nearest_id

func _do_dash() -> void:
    if dash_cooldown > 0.0:
        return
    dash_cooldown = 1.1
    dash_flash = 1.0
    var direction := facing
    if move_input.length() > 0.1:
        direction = move_input.normalized()
    player_pos += direction * 112.0
    var s := get_viewport_rect().size
    player_pos.x = clampf(player_pos.x, 38.0, s.x - 38.0)
    player_pos.y = clampf(player_pos.y, 42.0, s.y - 42.0)

func _do_skill() -> void:
    if skill_flash > 0.0:
        return
    skill_flash = 1.0

func _draw() -> void:
    var s := get_viewport_rect().size
    draw_rect(Rect2(Vector2.ZERO, s), Color("#426c36"))
    _draw_meadow(s)
    _draw_forest_props()
    _draw_grass_lens()
    _draw_enemies()
    _draw_player()
    _draw_projectiles()
    _draw_vignette(s)
    _draw_controls(s)
    _draw_hud(s)

func _draw_meadow(s: Vector2) -> void:
    # Deep forest floor: several low-contrast color layers create depth before the grass is drawn.
    draw_rect(Rect2(Vector2.ZERO, s), Color("#263d27"))
    draw_rect(Rect2(Vector2(0, s.y * 0.10), Vector2(s.x, s.y * 0.90)), Color(0.12, 0.24, 0.12, 0.58))
    for i in range(26):
        var p := Vector2(fposmod(float(i * 173) + 31.0, s.x), fposmod(float(i * 127) + 77.0, s.y))
        var radius := minf(s.x, s.y) * (0.045 + float(i % 4) * 0.018)
        var shade := Color("#45603a") if i % 2 == 0 else Color("#182d20")
        draw_circle(p, radius, Color(shade.r, shade.g, shade.b, 0.18))
    # Fine ground litter and tiny moss flecks between the grass clumps.
    for i in range(300):
        var x := fposmod(float(i * 83 + 19), s.x)
        var y := fposmod(float(i * 137 + 47), s.y)
        var len := 2.0 + float(i % 5) * 1.25
        var c := Color("#587346") if i % 3 == 0 else Color("#172b1e")
        draw_line(Vector2(x, y), Vector2(x + float((i % 5) - 2) * 1.2, y - len), Color(c.r, c.g, c.b, 0.65), 1.0)
    # Individual tapered blades with subtle wind sway. The closer blades are taller and brighter.
    for blade in grass_blades:
        var base: Vector2 = blade["p"]
        var h: float = blade["h"]
        var w: float = blade["w"]
        var lean: float = blade["lean"]
        var phase: float = blade["phase"]
        var tone: int = blade["tone"]
        var depth := clampf(base.y / s.y, 0.0, 1.0)
        var sway := sin(time_passed * (1.25 + depth * 0.65) + phase) * (1.4 + depth * 1.8)
        var tip := base + Vector2(lean + sway, -h)
        var mid := base.lerp(tip, 0.56) + Vector2(sway * 0.18, 0.0)
        var col: Color = grass_colors[tone]
        col = col.darkened(0.28) if depth < 0.22 else col
        var poly := PackedVector2Array([
            base + Vector2(-w, 0),
            mid + Vector2(-w * 0.52, h * 0.16),
            tip,
            mid + Vector2(w * 0.42, h * 0.13),
            base + Vector2(w, 0)
        ])
        draw_colored_polygon(poly, col)
        if tone >= 3:
            draw_line(base + Vector2(0, -1), tip, Color(col.r + 0.12, col.g + 0.12, col.b + 0.06, 0.42), 0.8)

func _draw_forest_props() -> void:
    for item in rocks:
        var p: Vector2 = item["p"]
        var r: float = item["r"]
        draw_colored_polygon(PackedVector2Array([
            p + Vector2(-r, 1), p + Vector2(-r*0.5, -r*0.65), p + Vector2(r*0.45, -r*0.8),
            p + Vector2(r, -r*0.1), p + Vector2(r*0.7, r*0.55), p + Vector2(-r*0.6, r*0.6)
        ]), Color("#66795a"))
        draw_line(p + Vector2(-r*0.4, -r*0.3), p + Vector2(r*0.35, -r*0.45), Color("#9aa77b"), 1.5)
    for f in flowers:
        var p: Vector2 = f["p"]
        var k: int = f["kind"]
        var scale: float = f["scale"]
        var phase: float = f["phase"]
        var bend := sin(time_passed * 1.7 + phase) * 1.5
        draw_line(p, p + Vector2(bend, -5.0*scale), Color("#315c2b"), 1.2)
        var petal_color := Color("#f2e8bb")
        if k == 1: petal_color = Color("#e8c5f0")
        elif k == 2: petal_color = Color("#f5d85b")
        elif k == 3: petal_color = Color("#b7dcf2")
        elif k == 4: petal_color = Color("#f4a9a2")
        var center := p + Vector2(bend, -6.0*scale)
        for j in range(5):
            var a := TAU * float(j) / 5.0
            draw_circle(center + Vector2(cos(a), sin(a))*2.7*scale, 1.8*scale, petal_color)
        draw_circle(center, 1.5*scale, Color("#e6b84e"))
    for t in trees:
        var p: Vector2 = t["p"]
        var r: float = t["r"]
        var tone: float = t["tone"]
        draw_circle(p + Vector2(2, 7), r*1.1, Color(0.04, 0.12, 0.06, 0.30))
        draw_line(p + Vector2(0, r*0.4), p + Vector2(0, r*1.15), Color("#634b2c"), r*0.30)
        var leaf := Color("#234d2b").lerp(Color("#49773a"), tone)
        draw_circle(p + Vector2(-r*0.32, -r*0.2), r*0.70, leaf)
        draw_circle(p + Vector2(r*0.32, -r*0.25), r*0.72, leaf.lightened(0.08))
        draw_circle(p + Vector2(0, -r*0.60), r*0.76, leaf.lightened(0.15))
        draw_circle(p + Vector2(-r*0.12, -r*0.52), r*0.32, Color(0.62, 0.78, 0.34, 0.20))

func _draw_grass_lens() -> void:
    var radius := 70.0
    var pulse := 1.0 + sin(time_passed * 3.2) * 0.035
    draw_circle(player_pos + Vector2(0, 8), radius * pulse, Color(0.82, 0.91, 0.48, 0.06))
    draw_arc(player_pos + Vector2(0, 8), radius * pulse, 0, TAU, 48, Color(0.91, 0.95, 0.62, 0.18), 1.6)
    for i in range(30):
        var a := TAU * float(i) / 30.0
        var inner := 28.0 + sin(a * 3.0 + time_passed * 2.0) * 3.0
        var outer := 46.0 + cos(a * 4.0 - time_passed) * 5.0
        draw_line(player_pos + Vector2(cos(a), sin(a)) * inner, player_pos + Vector2(cos(a + 0.13), sin(a + 0.13)) * outer, Color(0.70, 0.88, 0.43, 0.42), 1.4)

func _draw_vignette(s: Vector2) -> void:
    # Layered black edge falloff: darkest in the corners, fading smoothly toward the play area.
    var layers := 8
    for i in range(layers):
        var t := float(i) / float(layers)
        var inset := float(i) * 12.0
        var alpha := 0.20 * pow(1.0 - t, 1.55)
        var rect := Rect2(Vector2(inset, inset), s - Vector2(inset * 2.0, inset * 2.0))
        draw_rect(rect, Color(0.0, 0.008, 0.006, alpha), false, 10.0)
    # Deepen the very corners without creating a hard rectangular frame.
    var corner := Color(0.0, 0.0, 0.0, 0.18)
    draw_circle(Vector2(0, 0), minf(s.x, s.y) * 0.23, corner)
    draw_circle(Vector2(s.x, 0), minf(s.x, s.y) * 0.23, corner)
    draw_circle(Vector2(0, s.y), minf(s.x, s.y) * 0.23, corner)
    draw_circle(s, minf(s.x, s.y) * 0.23, corner)

func _draw_player() -> void:
    # Animation is procedural: body bob, flame wobble, and alternating bent limbs.
    var moving := move_input.length() > 0.05
    var bob := sin(time_passed * (10.0 if moving else 2.5)) * (2.6 if moving else 1.5)
    var lean := clampf(facing.x, -1.0, 1.0) * (2.0 if moving else 0.5)
    var body := player_pos + Vector2(lean, bob)
    if dash_flash > 0.0:
        for i in range(5):
            var trail_pos := player_pos - facing * float(i+1) * 15.0
            draw_circle(trail_pos, 15.0 - float(i)*2.0, Color(0.75, 1.0, 0.36, 0.14 * dash_flash))
    var glow := 0.07 + (sin(time_passed * 4.0) + 1.0) * 0.025
    draw_circle(body, 41.0, Color(0.80, 1.0, 0.30, glow))
    draw_circle(body, 29.0, Color(0.87, 1.0, 0.40, 0.13))
    var stride := sin(walk_phase) * (9.0 if moving else 1.2)
    var arm_swing := sin(walk_phase + PI) * (7.0 if moving else 1.0)
    var ink := Color("#3d3825")
    # Bent legs, animated independently.
    var left_hip := body + Vector2(-8, 12)
    var left_knee := body + Vector2(-12 + stride*0.35, 18 + absf(stride)*0.18)
    var left_foot := body + Vector2(-15 + stride, 22 - maxf(0.0, stride)*0.22)
    var right_hip := body + Vector2(8, 12)
    var right_knee := body + Vector2(12 - stride*0.35, 18 + absf(stride)*0.18)
    var right_foot := body + Vector2(15 - stride, 22 + minf(0.0, stride)*0.22)
    draw_line(left_hip, left_knee, ink, 3.0)
    draw_line(left_knee, left_foot, ink, 3.0)
    draw_line(right_hip, right_knee, ink, 3.0)
    draw_line(right_knee, right_foot, ink, 3.0)
    # Arms swing opposite the legs and keep a little elbow bend.
    var left_shoulder := body + Vector2(-14, -2)
    var left_elbow := body + Vector2(-20 - arm_swing*0.35, 1 + arm_swing*0.15)
    var left_hand := body + Vector2(-24 - arm_swing, -2 + arm_swing*0.25)
    var right_shoulder := body + Vector2(14, -2)
    var right_elbow := body + Vector2(20 + arm_swing*0.35, 1 - arm_swing*0.15)
    var right_hand := body + Vector2(24 + arm_swing, -2 - arm_swing*0.25)
    draw_line(left_shoulder, left_elbow, ink, 3.0)
    draw_line(left_elbow, left_hand, ink, 3.0)
    draw_line(right_shoulder, right_elbow, ink, 3.0)
    draw_line(right_elbow, right_hand, ink, 3.0)
    # The head itself is a pale, semi-transparent ghost flame; its silhouette changes every frame.
    var flame_wobble := sin(time_passed * 6.4) * 2.2
    var flame_side := sin(time_passed * 4.7 + 0.8) * 1.7
    draw_circle(body + Vector2(0, -4), 31.0, Color(0.60, 1.0, 0.49, 0.055 + glow * 0.35))
    var flame_points := PackedVector2Array([
        body + Vector2(-19, 12),
        body + Vector2(-23 + flame_side, 0),
        body + Vector2(-19, -10),
        body + Vector2(-17 + flame_side, -20 - flame_wobble * 0.4),
        body + Vector2(-8, -15),
        body + Vector2(-3 + flame_side, -30 - absf(flame_wobble)),
        body + Vector2(5, -20),
        body + Vector2(13 - flame_side, -26 + flame_wobble * 0.6),
        body + Vector2(15, -13),
        body + Vector2(22, -4),
        body + Vector2(18, 9),
        body + Vector2(11, 16),
        body + Vector2(-9, 17)
    ])
    draw_colored_polygon(flame_points, Color(0.64, 1.0, 0.48, 0.73))
    draw_circle(body + Vector2(-1, 0), 17.5, Color(0.83, 1.0, 0.65, 0.46))
    draw_circle(body + Vector2(0, -2), 12.5, Color(0.91, 1.0, 0.76, 0.32))
    # Simple hand-drawn happy face: two curved closed eyes and one small smile.
    var face_ink := Color(0.12, 0.20, 0.13, 0.92)
    draw_arc(body + Vector2(-6.0, -3.0), 3.8, PI * 1.08, PI * 1.92, 12, face_ink, 1.8)
    draw_arc(body + Vector2(6.0, -3.0), 3.8, PI * 1.08, PI * 1.92, 12, face_ink, 1.8)
    draw_arc(body + Vector2(0.0, 1.0), 5.0, 0.22, PI - 0.22, 16, face_ink, 1.7)
    draw_circle(body + Vector2(-12, 5), 2.8, Color(1.0, 0.58, 0.52, 0.42))
    draw_circle(body + Vector2(12, 5), 2.8, Color(1.0, 0.58, 0.52, 0.42))

func _draw_enemies() -> void:
    # Small soot-black fuzzy creatures: layered dark circles and irregular fur tufts.
    for enemy in enemies:
        var p: Vector2 = enemy["p"]
        var r: float = enemy["r"]
        var phase: float = enemy["phase"]
        var wobble := sin(time_passed * 5.0 + phase) * 1.5
        draw_circle(p + Vector2(1.5, 4.0), r * 1.05, Color(0.01, 0.018, 0.014, 0.32))
        var hurt := float(enemy["hit_timer"]) > 0.0
        var is_boss := bool(enemy.get("boss", false))
        var body_color := Color("#e65d58") if hurt else (Color("#38251a") if is_boss else Color("#101411"))
        var highlight_color := Color("#ff9a86") if hurt else (Color("#b9823f") if is_boss else Color("#202720"))
        draw_circle(p + Vector2(0, wobble), r, body_color)
        draw_circle(p + Vector2(-r * 0.22, -r * 0.2 + wobble), r * 0.67, highlight_color)
        # Soft little tufts make the silhouette read like a fuzzy black plush toy.
        for k in range(7):
            var a := TAU * float(k) / 7.0 + phase * 0.12
            var tuft := p + Vector2(cos(a), sin(a)) * (r * 0.76)
            draw_circle(tuft, r * 0.24, Color("#f06b60") if hurt else Color("#111612"))
        if float(enemy["max_hp"]) > 10.0 or hurt:
            var hp_ratio := clampf(float(enemy["hp"]) / float(enemy["max_hp"]), 0.0, 1.0)
            draw_rect(Rect2(p + Vector2(-r, -r - 7.0), Vector2(r * 2.0, 3.0)), Color(0.02, 0.03, 0.02, 0.8), true)
            draw_rect(Rect2(p + Vector2(-r, -r - 7.0), Vector2(r * 2.0 * hp_ratio, 3.0)), Color("#d96a62"), true)
        if is_boss:
            draw_arc(p, r + 6.0, 0.0, TAU, 36, Color("#e7bd62"), 2.2)
            draw_string(ThemeDB.fallback_font, p + Vector2(-r, -r - 13.0), "大Boss" if String(enemy.get("boss_kind", "mini")) == "major" else "小Boss", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#f3d98b"))
        draw_circle(p + Vector2(-r * 0.28, -r * 0.10), maxf(1.4, r * 0.12), Color("#b7d78a"))
        draw_circle(p + Vector2(r * 0.20, -r * 0.10), maxf(1.4, r * 0.12), Color("#b7d78a"))
        draw_arc(p + Vector2(0, r * 0.12), r * 0.22, 0.15, PI - 0.15, 8, Color("#66785a"), 1.2)

func _draw_projectiles() -> void:
    for projectile in projectiles:
        var pos: Vector2 = projectile["p"]
        var golden := bool(projectile.get("golden", false))
        draw_circle(pos, 12.0 if golden else 10.0, Color(1.0, 0.68, 0.20, 0.25) if golden else Color(0.95, 1.0, 0.44, 0.16))
        draw_circle(pos, 6.0 if golden else 5.0, Color("#ffbd43") if golden else Color("#f8ff9a"))
        draw_circle(pos, 2.0, Color("#ffffff"))
    for drop in potion_drops:
        var dp: Vector2 = drop["p"]
        var potion_color := Color("#d74e43") if String(drop["kind"]) == "大" else (Color("#ed8760") if String(drop["kind"]) == "中" else Color("#f3c4a2"))
        draw_circle(dp, 9.0, Color(potion_color.r, potion_color.g, potion_color.b, 0.20))
        draw_circle(dp, 5.0, potion_color)
    for gold in golden_drops:
        var gp: Vector2 = gold["p"]
        draw_circle(gp, 12.0 + sin(time_passed * 4.0) * 2.0, Color(1.0, 0.73, 0.18, 0.18))
        draw_circle(gp, 5.0, Color("#ffd34e"))
    for weapon_drop in weapon_drops:
        var wp: Vector2 = weapon_drop["p"]
        draw_circle(wp, 15.0 + sin(time_passed * 3.0) * 2.0, Color(1.0, 0.78, 0.24, 0.20))
        draw_arc(wp, 11.0, 0.0, TAU, 24, Color("#ffe38a"), 2.0)
        draw_string(ThemeDB.fallback_font, wp + Vector2(-5.0, 5.0), "★", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#ffe38a"))
    if attack_flash > 0.0:
        draw_arc(player_pos, 48.0, attack_angle - 0.7, attack_angle + 0.7, 24, Color(1.0, 0.94, 0.46, attack_flash * 0.8), 3.5)

func _draw_controls(s: Vector2) -> void:
    var c := _control_centers(s)
    var joy_center: Vector2 = c["joy"]
    # Large left-bottom virtual stick, sized for landscape touch screens.
    draw_circle(joy_center + Vector2(0, 3), JOYSTICK_RADIUS + 8, Color(0.01, 0.03, 0.025, 0.35))
    draw_circle(joy_center, JOYSTICK_RADIUS, Color(0.04, 0.10, 0.08, 0.66))
    draw_arc(joy_center, JOYSTICK_RADIUS, 0, TAU, 48, Color(0.73, 0.86, 0.60, 0.72), 2.8)
    var knob := joystick_knob if joystick_touch != -1 else joy_center
    draw_circle(knob, 29.0, Color(0.70, 0.83, 0.67, 0.56))
    draw_arc(knob, 29.0, 0, TAU, 32, Color(0.91, 0.97, 0.80, 0.82), 2.0)
    # Attack is the largest button; dash sits above and slightly left, MOBA-style.
    _draw_button(c["dash"], 40.0, Color("#d5b94e"), "➤", dash_cooldown > 0.0)
    _draw_button(c["attack"], ATTACK_RADIUS, Color("#edc34e"), "✦", attack_cooldown > 0.0)
    _draw_button(c["pause"], 22.0, Color("#d4e4bd"), "Ⅱ", false)

func _draw_button(center: Vector2, radius: float, accent: Color, symbol: String, cooling: bool) -> void:
    draw_circle(center + Vector2(0, 3), radius + 4, Color(0.02, 0.06, 0.04, 0.38))
    draw_circle(center, radius, Color(0.035, 0.085, 0.08, 0.91))
    draw_arc(center, radius, 0, TAU, 36, accent.darkened(0.15), 3.0)
    draw_arc(center, radius - 4, 0, TAU, 36, Color(accent.r, accent.g, accent.b, 0.42), 1.2)
    if cooling:
        draw_circle(center, radius * 0.75, Color(0.02, 0.04, 0.03, 0.42))
    var font := ThemeDB.fallback_font
    var fs := int(radius * 0.68)
    var text_size := font.get_string_size(symbol, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
    draw_string(font, center - Vector2(text_size.x / 2.0, -text_size.y * 0.34), symbol, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("#fff8d6"))

func _draw_hud(s: Vector2) -> void:
    var font := ThemeDB.fallback_font
    var c := _control_centers(s)
    # HUD cluster sits below the pause button at the top-left, clear of the joystick.
    var portrait := Vector2(s.x * 0.055, s.y * 0.205)
    draw_circle(portrait, 28.0, Color(0.015, 0.04, 0.03, 0.88))
    draw_arc(portrait, 28.0, 0, TAU, 40, Color("#b6d88b"), 2.0)
    draw_circle(portrait + Vector2(0, -5), 13.0, Color(0.58, 0.95, 0.45, 0.22))
    # Character portrait: pale-green ghost flame, closed smiling eyes and stick body.
    draw_colored_polygon(PackedVector2Array([portrait + Vector2(-10, 5), portrait + Vector2(-12, -5), portrait + Vector2(-5, -13), portrait + Vector2(-1, -20), portrait + Vector2(4, -12), portrait + Vector2(11, -9), portrait + Vector2(10, 3), portrait + Vector2(5, 9), portrait + Vector2(-5, 9)]), Color(0.70, 1.0, 0.58, 0.90))
    draw_arc(portrait + Vector2(-4, -3), 2.4, PI * 1.1, PI * 1.9, 8, Color("#29452a"), 1.1)
    draw_arc(portrait + Vector2(4, -3), 2.4, PI * 1.1, PI * 1.9, 8, Color("#29452a"), 1.1)
    draw_arc(portrait + Vector2(0, 0), 3.2, 0.25, PI - 0.25, 8, Color("#29452a"), 1.0)
    draw_line(portrait + Vector2(0, 8), portrait + Vector2(0, 16), Color("#d6e8bd"), 2.0)
    draw_line(portrait + Vector2(0, 11), portrait + Vector2(-5, 15), Color("#d6e8bd"), 1.5)
    draw_line(portrait + Vector2(0, 11), portrait + Vector2(5, 15), Color("#d6e8bd"), 1.5)

    var panel_x := s.x * 0.095
    var bar_pos := Vector2(panel_x, s.y * 0.155)
    var bar_size := Vector2(minf(172.0, s.x * 0.145), 10.0)
    draw_rect(Rect2(bar_pos, bar_size), Color(0.01, 0.03, 0.025, 0.92), true)
    draw_rect(Rect2(bar_pos, Vector2(bar_size.x * clampf(health / max_health, 0.0, 1.0), bar_size.y)), Color("#d66f6c"), true)
    draw_string(font, bar_pos + Vector2(0, -5), "生命 %d/%d" % [int(health), int(max_health)], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#f2e8d1"))
    # Soft glowing EXP bar, same width as the health bar.
    var exp_pos := bar_pos + Vector2(0, 17.0)
    draw_rect(Rect2(exp_pos, bar_size), Color(0.01, 0.03, 0.025, 0.92), true)
    var exp_ratio := float(exp_points) / float(maxi(exp_to_next, 1))
    var exp_fill := Rect2(exp_pos, Vector2(bar_size.x * clampf(exp_ratio, 0.0, 1.0), bar_size.y))
    draw_rect(exp_fill, Color(0.50, 0.88, 0.52, 0.88), true)
    draw_rect(Rect2(exp_pos + Vector2(0, 0), Vector2(exp_fill.size.x, 2.0)), Color(0.76, 1.0, 0.72, 0.7), true)
    draw_string(font, exp_pos + Vector2(0, 22), "EXP %d/%d  ·  LV %d" % [exp_points, exp_to_next, player_level], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#c9efb5"))
    var time_left := maxi(0, int(ceil(LEVEL_DURATION - level_time)))
    var time_text := "%02d:%02d" % [int(time_left / 60), time_left % 60]
    var stage_text := "第 %d 关   %s   击败 %d/%d" % [run_level, time_text, enemies_defeated, enemy_target_count]
    var stage_size := font.get_string_size(stage_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 18)
    draw_round_rect(Rect2(Vector2(s.x * 0.5 - stage_size.x * 0.5 - 15, 18), Vector2(stage_size.x + 30, 34)), 8.0, Color(0.015, 0.04, 0.03, 0.68))
    draw_string(font, Vector2(s.x * 0.5 - stage_size.x * 0.5, 41), stage_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#e1edce"))

    # Health and basic attack use LV labels; defense and movement speed remain percentages.
    var stats := ["生命", "基础攻击", "防御", "移速"]
    var values := ["LV %d" % talent_levels["生命"], "LV %d" % talent_levels["攻击"], "%d%%" % (talent_levels["防御"] * 5), "%d%%" % (100 + (talent_levels["移速"] - 1) * 5)]
    for i in range(4):
        var y := s.y * 0.245 + float(i) * 22.0
        var stat_rect := Rect2(panel_x, y, minf(172.0, s.x * 0.145), 18.0)
        draw_round_rect(stat_rect, 4.0, Color(0.015, 0.04, 0.03, 0.78))
        draw_string(font, Vector2(panel_x + 7.0, y + 13.0), stats[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#d5e6bf"))
        draw_string(font, Vector2(stat_rect.end.x - 5.0, y + 13.0), values[i], HORIZONTAL_ALIGNMENT_RIGHT, -1, 11, Color("#f4e9c8"))

    var weapon_label := "武器 ★" + "★".repeat(weapon_star - 1)
    draw_string(font, Vector2(s.x * 0.80, s.y * 0.16), weapon_label, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#f1d77a"))
    if fire_buff_timer > 0.0 and STAR_FIRE_BUFF.has(weapon_star):
        var bonus_text := "+%d%% 射速  %.1fs" % [int(round(float(STAR_FIRE_BUFF[weapon_star]["bonus"]) * 100.0)), fire_buff_timer]
        draw_string(font, Vector2(s.x * 0.80, s.y * 0.20), bonus_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#ffd06a"))
    if golden_shots > 0:
        draw_string(font, Vector2(s.x * 0.80, s.y * 0.235), "金色追踪弹 ×%d" % golden_shots, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#ffdc64"))
    # Equipment slots remain along the far-right edge, away from the attack controls.
    var potion_labels := ["大", "中", "小", "✦"]
    for i in range(equipment_slots):
        var slot := Rect2(s.x * 0.945, s.y * 0.47 + float(i) * 39.0, 31.0, 31.0)
        draw_round_rect(slot, 5.0, Color(0.015, 0.04, 0.03, 0.72))
        draw_round_rect_outline(slot, 5.0, Color(0.52, 0.66, 0.43, 0.78), 1.5)
        if i < 3:
            var potion_count := int(potion_counts[potion_labels[i]])
            draw_circle(slot.position + slot.size * 0.5, 6.0, Color("#d74e43") if i == 0 else (Color("#ed8760") if i == 1 else Color("#f3c4a2")))
            draw_string(font, slot.position + Vector2(19.0, 28.0), str(potion_count), HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#ffffff"))
        else:
            draw_circle(slot.position + slot.size * 0.5, 3.0, Color(0.63, 0.77, 0.48, 0.28))
    if upgrade_pending:
        _draw_upgrade_menu(s)
    if game_paused:
        _draw_pause_menu(s)
    if game_over or game_complete:
        draw_rect(Rect2(Vector2.ZERO, s), Color(0.005, 0.015, 0.012, 0.78), true)
        var end_title := "挑战结束" if game_over else "百关完成！"
        var title_size := font.get_string_size(end_title, HORIZONTAL_ALIGNMENT_CENTER, -1, 32)
        draw_string(font, Vector2(s.x * 0.5 - title_size.x * 0.5, s.y * 0.36), end_title, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color("#eef5d8"))
        _draw_menu_button(_control_centers(s)["restart"], "重新挑战", Color("#c1a65a"))

func _draw_upgrade_menu(s: Vector2) -> void:
    draw_rect(Rect2(Vector2.ZERO, s), Color(0.005, 0.015, 0.012, 0.88), true)
    var font := ThemeDB.fallback_font
    var title := "第 %d 关完成 · 选择一项天赋" % run_level
    var title_size := font.get_string_size(title, HORIZONTAL_ALIGNMENT_CENTER, -1, 27)
    draw_string(font, Vector2((s.x - title_size.x) * 0.5, s.y * 0.22), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color("#eaf6d7"))
    var names := ["生命", "基础攻击", "防御", "移速"]
    var descriptions := ["最大生命 +20\n并恢复 20 点", "攻击伤害 +3", "伤害减免 +5%", "移动速度 +5%"]
    var values := ["LV %d" % talent_levels["生命"], "LV %d" % talent_levels["攻击"], "%d%%" % (talent_levels["防御"] * 5), "%d%%" % (100 + (talent_levels["移速"] - 1) * 5)]
    var card_width := minf(245.0, s.x * 0.22)
    var gap := 14.0
    var total := card_width * 4.0 + gap * 3.0
    var left := (s.x - total) * 0.5
    var accents := [Color("#91c977"), Color("#e6c45d"), Color("#83b8b0"), Color("#a9d8a0")]
    for i in range(4):
        var rect := Rect2(Vector2(left + float(i) * (card_width + gap), s.y * 0.38), Vector2(card_width, 190.0))
        draw_round_rect(rect, 12.0, Color("#17291e"))
        draw_round_rect_outline(rect, 12.0, accents[i], 2.0)
        draw_circle(rect.position + Vector2(card_width * 0.5, 42.0), 19.0, Color(accents[i].r, accents[i].g, accents[i].b, 0.18))
        draw_arc(rect.position + Vector2(card_width * 0.5, 42.0), 15.0, 0, TAU, 32, accents[i], 2.0)
        var name_size := font.get_string_size(names[i], HORIZONTAL_ALIGNMENT_CENTER, -1, 19)
        draw_string(font, Vector2(rect.position.x + (card_width - name_size.x) * 0.5, rect.position.y + 80.0), names[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#f1f2dc"))
        var value_size := font.get_string_size(values[i], HORIZONTAL_ALIGNMENT_CENTER, -1, 16)
        draw_string(font, Vector2(rect.position.x + (card_width - value_size.x) * 0.5, rect.position.y + 107.0), values[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 16, accents[i])
        var lines: PackedStringArray = descriptions[i].split("\n")
        for j in range(lines.size()):
            var line_size := font.get_string_size(lines[j], HORIZONTAL_ALIGNMENT_CENTER, -1, 13)
            draw_string(font, Vector2(rect.position.x + (card_width - line_size.x) * 0.5, rect.position.y + 137.0 + float(j) * 17.0), lines[j], HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#cbd9bd"))

func _draw_pause_menu(s: Vector2) -> void:
    draw_rect(Rect2(Vector2.ZERO, s), Color(0.005, 0.015, 0.012, 0.76), true)
    var center := Vector2(s.x * 0.5, s.y * 0.5)
    draw_round_rect(Rect2(center - Vector2(185, 160), Vector2(370, 320)), 18.0, Color("#17291e"))
    draw_round_rect_outline(Rect2(center - Vector2(185, 160), Vector2(370, 320)), 18.0, Color("#9cb77b"), 2.0)
    draw_string(ThemeDB.fallback_font, center + Vector2(-55, -112), "暂停菜单", HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color("#eef5d8"))
    var c := _control_centers(s)
    _draw_menu_button(c["continue"], "继续", Color("#6d9f55"))
    _draw_menu_button(c["restart"], "重新挑战", Color("#c1a65a"))
    _draw_menu_button(c["exit"], "退出", Color("#9a6658"))

func _draw_menu_button(center: Vector2, label: String, accent: Color) -> void:
    var rect := Rect2(center - Vector2(145, 23), Vector2(290, 46))
    draw_round_rect(rect, 8.0, Color(0.045, 0.09, 0.065, 0.98))
    draw_round_rect_outline(rect, 8.0, accent, 2.0)
    var font := ThemeDB.fallback_font
    var sz := font.get_string_size(label, HORIZONTAL_ALIGNMENT_CENTER, -1, 18)
    draw_string(font, center - Vector2(sz.x * 0.5, -sz.y * 0.34), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#f3f2d9"))

func draw_round_rect(rect: Rect2, radius: float, color: Color) -> void:
    draw_rect(Rect2(rect.position + Vector2(radius, 0), Vector2(rect.size.x - radius * 2.0, rect.size.y)), color, true)
    draw_rect(Rect2(rect.position + Vector2(0, radius), Vector2(rect.size.x, rect.size.y - radius * 2.0)), color, true)
    draw_circle(rect.position + Vector2(radius, radius), radius, color)
    draw_circle(rect.position + Vector2(rect.size.x - radius, radius), radius, color)
    draw_circle(rect.position + Vector2(radius, rect.size.y - radius), radius, color)
    draw_circle(rect.position + rect.size - Vector2(radius, radius), radius, color)

func draw_round_rect_outline(rect: Rect2, radius: float, color: Color, width: float) -> void:
    draw_line(rect.position + Vector2(radius, 0), rect.position + Vector2(rect.size.x - radius, 0), color, width)
    draw_line(rect.position + Vector2(radius, rect.size.y), rect.position + Vector2(rect.size.x - radius, rect.size.y), color, width)
    draw_line(rect.position + Vector2(0, radius), rect.position + Vector2(0, rect.size.y - radius), color, width)
    draw_line(rect.position + Vector2(rect.size.x, radius), rect.position + Vector2(rect.size.x, rect.size.y - radius), color, width)
    draw_arc(rect.position + Vector2(radius, radius), radius, PI, PI * 1.5, 10, color, width)
    draw_arc(rect.position + Vector2(rect.size.x - radius, radius), radius, PI * 1.5, TAU, 10, color, width)
    draw_arc(rect.position + Vector2(rect.size.x - radius, rect.size.y - radius), radius, 0, PI * 0.5, 10, color, width)
    draw_arc(rect.position + Vector2(radius, rect.size.y - radius), radius, PI * 0.5, PI, 10, color, width)

func _restart_run() -> void:
    var s := get_viewport_rect().size
    player_pos = s * Vector2(0.5, 0.51)
    health = max_health
    talent_levels = {"生命": 1, "攻击": 1, "防御": 1, "移速": 1}
    player_level = 0
    exp_points = 0
    exp_to_next = 5
    game_over = false
    game_complete = false
    next_enemy_id = 1
    _start_stage(1)
    projectiles.clear()
    potion_counts = {"大": 0, "中": 0, "小": 0}
    potion_drop_total = 0
    weapon_star = 1
    kill_streak_for_fire = 0
    fire_buff_timer = 0.0
    golden_shots = 0
    attack_cooldown = 0.0
    dash_cooldown = 0.0
    player_hit_cooldown = 0.0
    attack_flash = 0.0
    dash_flash = 0.0
    move_input = Vector2.ZERO
    joystick_touch = -1
    game_paused = false
    upgrade_pending = false
    _reset_joystick()
    queue_redraw()
